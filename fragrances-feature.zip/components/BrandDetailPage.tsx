'use client';

import Link from 'next/link';
import { motion, type Variants } from 'framer-motion';
import { getBrandGroup } from '@/lib/brands';
import FragranceCard from './FragranceCard';

interface BrandDetailPageProps {
  brand: string;
  onBack: () => void;
  onViewShelf: () => void;
}

const listVariants: Variants = {
  animate: {
    transition: { staggerChildren: 0.06, delayChildren: 0.05 },
  },
};

const itemVariants: Variants = {
  initial: { opacity: 0, y: 16 },
  animate: { opacity: 1, y: 0, transition: { duration: 0.35, ease: 'easeOut' } },
};

export default function BrandDetailPage({ brand, onBack, onViewShelf }: BrandDetailPageProps) {
  const group = getBrandGroup(brand);

  return (
    <div className="min-h-screen bg-stone-50">
      <header className="sticky top-0 z-10 border-b border-stone-200/80 bg-stone-50/90 px-4 py-4 backdrop-blur sm:px-6">
        <div className="mx-auto flex max-w-2xl items-center justify-between">
          <button
            type="button"
            onClick={onBack}
            className="flex items-center gap-1.5 text-sm text-stone-500 transition-colors hover:text-stone-950"
          >
            <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
            All brands
          </button>
          <span className="text-sm font-semibold tracking-tight text-stone-950">ScentMatch</span>
          <div className="flex min-w-16 items-center justify-end gap-3 text-right">
            <Link href="/about" className="text-xs text-stone-400 transition-colors hover:text-stone-950">About</Link>
            <button
              type="button"
              onClick={onViewShelf}
              className="text-xs text-stone-400 transition-colors hover:text-stone-950"
            >
              Shelf
            </button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-2xl px-4 py-10 sm:px-6 sm:py-14">
        {group ? (
          <>
            <div className="mb-8">
              <p className="mb-2 text-xs font-medium uppercase tracking-[0.22em] text-stone-400">{group.tierLabel}</p>
              <h1 className="text-4xl font-semibold tracking-tight text-stone-950">{group.name}</h1>
              <p className="mt-3 max-w-xl text-sm font-light leading-relaxed text-stone-500">
                {group.fragrances.length} {group.fragrances.length === 1 ? 'fragrance' : 'fragrances'} in the catalogue. Add any of them to your Shelf to revisit later.
              </p>
            </div>

            <motion.div variants={listVariants} initial="initial" animate="animate" className="space-y-5">
              {group.fragrances.map(fragrance => (
                <motion.div key={fragrance.id} variants={itemVariants}>
                  <FragranceCard fragrance={fragrance} />
                </motion.div>
              ))}
            </motion.div>
          </>
        ) : (
          <div className="rounded-3xl border border-stone-200 bg-white px-6 py-14 text-center sm:px-10">
            <h1 className="font-medium text-stone-950">We couldn’t find that brand.</h1>
            <p className="mx-auto mt-2 max-w-md text-sm font-light leading-relaxed text-stone-500">
              It may have been removed from the catalogue.
            </p>
            <button
              type="button"
              onClick={onBack}
              className="mt-6 rounded-xl bg-stone-950 px-6 py-3 text-sm font-medium text-white transition-colors hover:bg-stone-800"
            >
              Browse all brands
            </button>
          </div>
        )}
      </main>
    </div>
  );
}
