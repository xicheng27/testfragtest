'use client';

import Link from 'next/link';
import { useMemo, useState } from 'react';
import { motion, type Variants } from 'framer-motion';
import { brandGroups } from '@/lib/brands';
import { fragrances } from '@/lib/fragrances';
import ProductImage from './ProductImage';

interface BrandsPageProps {
  onBack: () => void;
  onSelectBrand: (brand: string) => void;
}

const gridVariants: Variants = {
  animate: {
    transition: { staggerChildren: 0.035, delayChildren: 0.05 },
  },
};

const cardVariants: Variants = {
  initial: { opacity: 0, y: 14 },
  animate: { opacity: 1, y: 0, transition: { duration: 0.3, ease: 'easeOut' } },
};

export default function BrandsPage({ onBack, onSelectBrand }: BrandsPageProps) {
  const [query, setQuery] = useState('');

  const visibleBrands = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return brandGroups;
    return brandGroups.filter(group => group.name.toLowerCase().includes(q));
  }, [query]);

  return (
    <div className="min-h-screen bg-stone-50">
      <header className="sticky top-0 z-10 border-b border-stone-200/80 bg-stone-50/90 px-4 py-4 backdrop-blur sm:px-6">
        <div className="mx-auto flex max-w-5xl items-center justify-between">
          <button
            type="button"
            onClick={onBack}
            className="flex items-center gap-1.5 text-sm text-stone-500 transition-colors hover:text-stone-950"
          >
            <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
            Back
          </button>
          <span className="text-sm font-semibold tracking-tight text-stone-950">ScentMatch</span>
          <div className="flex min-w-16 items-center justify-end gap-3 text-right">
            <Link href="/about" className="text-xs text-stone-400 transition-colors hover:text-stone-950">About</Link>
            <span className="text-xs text-stone-400">
              {brandGroups.length} brands
            </span>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-5xl px-4 py-10 sm:px-6 sm:py-14">
        <div className="mb-8">
          <p className="mb-2 text-xs font-medium uppercase tracking-[0.22em] text-stone-400">The catalogue</p>
          <h1 className="text-4xl font-semibold tracking-tight text-stone-950">Fragrances</h1>
          <p className="mt-3 max-w-xl text-sm font-light leading-relaxed text-stone-500">
            Browse all {fragrances.length} fragrances across {brandGroups.length} houses, from everyday designers to rare niche perfumers. Select a brand to explore its full lineup.
          </p>
        </div>

        <div className="mb-8">
          <label htmlFor="brand-search" className="sr-only">Search brands</label>
          <div className="relative max-w-sm">
            <svg
              className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-stone-400"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-4.35-4.35M17 10.5a6.5 6.5 0 11-13 0 6.5 6.5 0 0113 0z" />
            </svg>
            <input
              id="brand-search"
              type="search"
              value={query}
              onChange={event => setQuery(event.target.value)}
              placeholder="Search brands…"
              className="w-full rounded-xl border border-stone-200 bg-white py-2.5 pl-10 pr-4 text-sm text-stone-900 placeholder:text-stone-400 focus:border-stone-400 focus:outline-none"
            />
          </div>
        </div>

        {visibleBrands.length > 0 ? (
          <motion.div
            variants={gridVariants}
            initial="initial"
            animate="animate"
            className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3"
          >
            {visibleBrands.map(group => (
              <motion.button
                key={group.name}
                variants={cardVariants}
                type="button"
                onClick={() => onSelectBrand(group.name)}
                className="group flex flex-col overflow-hidden rounded-2xl border border-stone-200 bg-white text-left transition-all duration-200 hover:-translate-y-0.5 hover:border-stone-300 hover:shadow-lg focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-stone-900"
                aria-label={`View all ${group.fragrances.length} ${group.name} fragrances`}
              >
                <div className="grid grid-cols-3 gap-px border-b border-stone-100 bg-stone-100">
                  {group.fragrances.slice(0, 3).map(fragrance => (
                    <div key={fragrance.id} className="relative aspect-square bg-white">
                      <ProductImage
                        src={fragrance.imageUrl}
                        alt={`${fragrance.brand} ${fragrance.name} bottle`}
                        sizes="(max-width: 640px) 33vw, 160px"
                        className="object-contain p-2.5 transition-transform duration-300 group-hover:scale-105"
                      />
                    </div>
                  ))}
                  {group.fragrances.length < 3 &&
                    Array.from({ length: 3 - group.fragrances.length }).map((_, index) => (
                      <div key={`empty-${index}`} className="relative aspect-square bg-white" aria-hidden="true" />
                    ))}
                </div>
                <div className="flex flex-1 items-center justify-between gap-3 p-4">
                  <div className="min-w-0">
                    <h2 className="truncate font-semibold tracking-tight text-stone-950">{group.name}</h2>
                    <p className="mt-0.5 text-xs font-light text-stone-500">
                      {group.fragrances.length} {group.fragrances.length === 1 ? 'fragrance' : 'fragrances'} · {group.tierLabel}
                    </p>
                  </div>
                  <svg
                    className="h-4 w-4 shrink-0 text-stone-300 transition-all duration-200 group-hover:translate-x-0.5 group-hover:text-stone-700"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </div>
              </motion.button>
            ))}
          </motion.div>
        ) : (
          <div className="rounded-3xl border border-stone-200 bg-white px-6 py-14 text-center sm:px-10">
            <h2 className="font-medium text-stone-950">No brands match “{query.trim()}”.</h2>
            <p className="mx-auto mt-2 max-w-md text-sm font-light leading-relaxed text-stone-500">
              Try a different spelling, or clear the search to see every house.
            </p>
            <button
              type="button"
              onClick={() => setQuery('')}
              className="mt-6 rounded-xl border border-stone-300 px-6 py-3 text-sm font-medium text-stone-700 transition-colors hover:border-stone-500 hover:text-stone-950"
            >
              Clear search
            </button>
          </div>
        )}
      </main>
    </div>
  );
}
