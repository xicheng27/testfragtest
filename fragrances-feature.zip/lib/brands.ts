import { fragrances, Fragrance, Tier } from './fragrances';

export interface BrandGroup {
  name: string;
  fragrances: Fragrance[];
  tierLabel: string;
}

function tierLabelFor(items: Fragrance[]): string {
  const tiers = new Set<Tier>(items.map(f => f.tier));
  if (tiers.size === 1) return items[0].tier === 'niche' ? 'Niche' : 'Designer';
  return 'Designer & Niche';
}

const groups = new Map<string, Fragrance[]>();
for (const fragrance of fragrances) {
  const existing = groups.get(fragrance.brand);
  if (existing) {
    existing.push(fragrance);
  } else {
    groups.set(fragrance.brand, [fragrance]);
  }
}

export const brandGroups: BrandGroup[] = [...groups.entries()]
  .map(([name, items]) => ({
    name,
    fragrances: [...items].sort((a, b) => a.name.localeCompare(b.name)),
    tierLabel: tierLabelFor(items),
  }))
  .sort((a, b) => a.name.localeCompare(b.name, undefined, { sensitivity: 'base' }));

export function getBrandGroup(name: string): BrandGroup | undefined {
  return brandGroups.find(group => group.name === name);
}
